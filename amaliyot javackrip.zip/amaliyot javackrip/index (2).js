let row = document.querySelector("#row");


function col(user) {
  return `
    <div class="cola-mdv-4s mb-3 " style="flex: 0 0 auto;
  width: 33.33333333%;"  data-id="${user.id || ""}">
      <div class="card-img-top">
<img src="https://picsum.photos/300/200" alt="">
      </div>
      <div class="card-body">
        <h2 class="card-title">${user.name || ""}</h2>
        <p class="card-text">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi laudantium at cupiditate distinctio veritatis, iusto architecto nam pariatur dignissimos atque.
        </p>
      </div>
    </div>
  `;
}



document.addEventListener("DOMContentLoaded", () => {
  const row = document.querySelector("#row");

  fetch("https://jsonplaceholder.typicode.com/users")
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      row.innerHTML = "";

      data.forEach((user) => {
        const item = col(user);
        row.innerHTML += item;
      });

      let users = document.querySelectorAll(".col-md-4");

      users.forEach((user) => {
        user.addEventListener("click", () => {
          let id = user.getAttribute("data-id");
          window.location.assign(
            `http://127.0.0.1:5500/pages/about.html?id=${id}`
          );
        });
      });
    })
    .catch((error) => {
      console.error("Error fetching users:", error);
    });
});
